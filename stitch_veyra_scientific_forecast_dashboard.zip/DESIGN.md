---
name: Atmospheric Intelligence Mission Control
colors:
  surface: '#101419'
  surface-dim: '#101419'
  surface-bright: '#36393f'
  surface-container-lowest: '#0b0e14'
  surface-container-low: '#181c21'
  surface-container: '#1c2025'
  surface-container-high: '#272a30'
  surface-container-highest: '#31353b'
  on-surface: '#e0e2ea'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#e0e2ea'
  inverse-on-surface: '#2d3136'
  outline: '#849495'
  outline-variant: '#3a494b'
  surface-tint: '#00dce6'
  primary: '#e0fdff'
  on-primary: '#00373a'
  primary-container: '#00f2fe'
  on-primary-container: '#006a70'
  inverse-primary: '#00696f'
  secondary: '#7bd0ff'
  on-secondary: '#00354a'
  secondary-container: '#00a6e0'
  on-secondary-container: '#00374d'
  tertiary: '#fff5ee'
  on-tertiary: '#472a00'
  tertiary-container: '#ffd3a1'
  on-tertiary-container: '#875400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ff6ff'
  primary-fixed-dim: '#00dce6'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f53'
  secondary-fixed: '#c4e7ff'
  secondary-fixed-dim: '#7bd0ff'
  on-secondary-fixed: '#001e2c'
  on-secondary-fixed-variant: '#004c69'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#101419'
  on-background: '#e0e2ea'
  surface-variant: '#31353b'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0.02em
  body-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  telemetry-display:
    fontFamily: JetBrains Mono
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.03em
  telemetry-lg:
    fontFamily: JetBrains Mono
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: -0.01em
  telemetry-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
  telemetry-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.08em
spacing:
  gutter: 0.5rem
  gutter-mobile: 0.375rem
  margin: 0.75rem
  margin-mobile: 0.5rem
  space-xs: 0.25rem
  space-sm: 0.375rem
  space-md: 0.5rem
  space-lg: 0.75rem
  space-xl: 1rem
---

## Brand & Style

This design system embodies high-stakes orbital and planetary atmospheric telemetry. The interface is engineered for mission operators, climate physicists, and aerospace telemetry directors who parse multi-spectral sensor arrays, isobaric matrices, and real-time storm trajectory models under time-critical conditions.

The visual style is **High-Density Technical Minimalist with Micro-Luminescent Telemetry Accents**. Rather than decorative styling, every pixel, hairline rule, and hue carries semantic operational payload. The aesthetic draws from advanced aerospace avionics, laboratory spectrometry, and orbital mission consoles:
- **Surface Density & Discipline:** Minimal outer margins, tight functional groupings, and clear rectangular coordinate geometry maximize screen utilization.
- **Instrument Precision:** Hairline micro-borders (`1px`) establish hard visual separation between sensor telemetry nodes, while glowing cyan and crimson accents serve exclusively to signal status shifts and threshold breaches.
- **Atmospheric Depth:** Visual layers step downward into deep obsidian voids, evoking the vacuum of the upper stratosphere and exosphere.

## Colors

The palette is tuned for high-contrast visibility in low-light mission control environments, using dark obsidian tones to prevent operator fatigue while isolating telemetry signals through crisp spectral bands.

### Base Matrix & Surfaces
- **Obsidian Deep Void (`#06090e`):** Master viewport canvas, backdrop for radar overlays, and terminal ground.
- **Obsidian Module Tier 1 (`#0b111a`):** Primary panel containers, data cards, and telemetry module surfaces.
- **Obsidian Module Tier 2 (`#111927`):** Elevated sensor trays, modal flight directors, active inspector panes.
- **Obsidian Surface Interactive (`#1a2436`):** Hover states, selected telemetry rows, segmented toggle plates.
- **Obsidian Hairline Border (`#1e293b` / `rgba(56, 189, 248, 0.15)`): Crisp boundaries defining sensor cells.

### Telemetry Signals & Accents
- **Cryogenic Cyan (`#00f2fe`):** Primary system pulse, nominal vector locks, reticle crosshairs, active radar arcs, and selected metrics.
- **Stratosphere Blue (`#38bdf8`):** Secondary data stream, atmospheric pressure contours, axis typography, and secondary active states.
- **Cautionary Amber (`#f59e0b`):** Dynamic anomaly detection, atmospheric shear warning, unverified sensor feed, threshold alerts.
- **Calibrated Safe Emerald (`#10b981`):** Nominal telemetry sync, stable ground stations, sealed pressure seals, verified baselines.
- **Telemetry Crimson (`#f43f5e`):** Critical abort paths, catastrophic pressure drops, storm eyewall breaches, immediate operator intervention alerts.

### Chromatic Rules
- Never use `#00f2fe` for broad background fills; reserve it strictly for hairline strokes, vital numeric readouts, reticles, and pinpoint indicators.
- All non-semantic text adheres to muted cool-greys (`#94a3b8` for primary text, `#64748b` for labels, `#334155` for inactive telemetry markers).

## Typography

The typographic hierarchy enforces immediate visual separation between qualitative structural content and quantitative dynamic telemetry:

- **Structural & Narrative Typography (Inter):** Deployed for panel headers, operational briefings, analytical syntheses, and navigation controls. Neutral, highly legible at micro-scales, and stripped of idiosyncratic flourishes to ensure instant parsing under distress.
- **Instrument & Metric Typography (JetBrains Mono):** Mandated for all coordinates, isobaric measures, timestamps (UTC), radar azimuths, error coefficients, and status flags. Tabular figures (`tnum`) and zero-slashing are universally enforced to prevent horizontal jitter during rapid real-time updates.
- **Capitalization Protocol:** System status chips, data keys, parameter tags, and axis markers are strictly rendered in `label-caps` (all uppercase with `+0.08em` tracking).

## Layout & Spacing

This design system uses a strict **High-Density Modular Grid** optimized for multi-display mission consoles and technical workstations. Layouts default to an edge-to-edge docking model with minimal external canvas margins (`0.75rem`), treating every viewport region as active telemetry space.

### Grid & Architecture
- **Workstation Layout (Desktop / Console, 1440px+):** Fixed 16-column layout with rigid sub-panes. Lateral docks (Station matrix, Telemetry feed) occupy fixed 280px-340px columns, while central space houses multi-layer radar feeds and prediction interval graphs.
- **Tactical Reflow (Tablet / Field Terminal, 768px - 1439px):** 8-column layout with collapsible inspector drawers. Graph intervals compress their secondary axis readouts into popover diagnostics.
- **Mobile Handheld (320px - 767px):** 4-column layout; modules stack vertically with a fixed floating telemetry status bar at the top edge. Non-critical telemetry columns drop in favor of raw scalar status values.

### Spatial Discipline
- Inter-panel gutters are held firmly at `0.5rem` (`8px`) to enforce structural unity and simulate physical instrument rack rails.
- Component internal padding uses compact steps (`space-xs` for micro chips, `space-md` for standard telemetry cards) to maximize operational information density per square inch.

## Elevation & Depth

Depth in this system is conveyed not through heavy drop shadows, but through **layered obsidian luminance, low-contrast hairline containment, and selective cryogenic luminescence**.

### Depth Layers
- **Sub-Level (Canvas / Ground Plane):** `#06090e`. Acts as the coordinate radar background. Carries faint SVG geometric gridlines (`rgba(56, 189, 248, 0.05)`) with dot-matrix intersections at 32px intervals.
- **Base Level 1 (Telemetry Panels):** `#0b111a`. Bordered with `1px solid #1e293b`.
- **Raised Level 2 (Selected Cards, Floating Palettes, Active Feeds):** `#111927`. Bordered with `1px solid rgba(56, 189, 248, 0.3)`.
- **Overlay Level 3 (Alert Modals & Command Overlays):** `#162032` backdrop with a localized drop shadow of `0 0 24px rgba(0, 0, 0, 0.8)` and a bounding hairline of `1px solid #38bdf8`.

### Luminescent Accents
- Nominal surfaces feature no ambient box-shadows.
- Active anomalies, reticle focus points, and critical breach indicators utilize localized edge glows:
  - Cyan Focus: `box-shadow: 0 0 8px rgba(0, 242, 254, 0.35)`
  - Cautionary Warning: `box-shadow: 0 0 8px rgba(245, 158, 11, 0.4)`
  - Telemetry Crimson Breach: `box-shadow: 0 0 12px rgba(244, 63, 94, 0.5)`

## Shapes

The shape philosophy is strictly **Zero-Radius Architectural (`0` / Sharp)**.

- All containers, cards, buttons, telemetry cells, and status indicators have hard `0px` corners.
- To simulate milled avionics hardware and laser-calibrated instrumentation, primary panels and action toggles may incorporate **45-degree chamfered corners** (cut corners of 4px or 8px) created via CSS `clip-path: polygon(...)`.
- Circular forms are reserved exclusively for circular compass cards, radar polar plots, and circular sensor target reticles.

## Components

### Buttons & Mission Triggers
- **Primary Telemetry Trigger:** Sharp container (`roundedness: 0`), background `#00f2fe`, text `#06090e` (`Inter`, 600 weight, uppercase, `11px`). Hover adds a micro-glow `0 0 10px rgba(0, 242, 254, 0.5)`. Active state shifts to white `#ffffff`.
- **Secondary System Action:** `#0b111a` background, `1px solid #38bdf8`, text `#38bdf8`. Hover state fills with `rgba(56, 189, 248, 0.1)`.
- **Destructive / Abort Trigger:** Sharp container, hairline border `1px solid #f43f5e`, background `rgba(244, 63, 94, 0.08)`, text `#f43f5e`. On hover: `background: #f43f5e; color: #06090e;`.

### Scientific Status Chips & Badges
- Built using `label-caps` in `JetBrains Mono`.
- Height strictly set to `20px` with horizontal padding `6px`.
- Composed of a `4px` square pulsing status beacon followed by metric or state code (e.g., `[■] NOMINAL`, `[▲] SHEAR_WARN`, `[✕] LOSS_OF_SIGNAL`).
- Styling: `1px solid` border corresponding to status color, tinted background fill at `12%` opacity, and sharp edges.

### Cards & Telemetry Nodes
- Grounded in `#0b111a` with `1px solid #1e293b`.
- Headers include a top hairline accent bar (`2px` high) indicating the subsystem type (e.g., cryogenic cyan for stratospheric drift, amber for barometric instability).
- Internal layout is divided into tabular coordinate readouts with hairline dividers (`rgba(255, 255, 255, 0.05)`).

### Input Fields & Parameter Steppers
- Background: `#06090e` embedded within `#0b111a` panels.
- Border: `1px solid #334155`, focusing directly to `1px solid #00f2fe` without border-radius.
- Typography: `JetBrains Mono`, `13px`, `#e2e8f0`. Metric units (e.g., `hPa`, `m/s`, `ppm`) are right-anchored in `#64748b`.

### Conformal Prediction Interval Graphs & Radar Grids
- Graph canvas operates over `#06090e`.
- Grids: Fine dashed lines (`stroke-dasharray: 2, 2`) in `#1e293b`.
- The central prediction trajectory is plotted as a crisp `1.5px` stroke in `#00f2fe`.
- Conformal confidence intervals (90%, 95%) are visualized as layered translucent fills: outer band at `rgba(0, 242, 254, 0.08)` and inner core band at `rgba(0, 242, 254, 0.18)`.
- Upper and lower bound thresholds use hairline dotted lines in `#38bdf8`.

### High-Density Station Matrix Telemetry
- Dense tabular lists with alternate row shading (`#0b111a` and `#0e1622`).
- Fixed row heights of `28px`, padding `0 8px`.
- Numeric values are right-aligned, monospaced, with decimal points aligned.
- Threshold violations trigger an instant flashing cell background in `rgba(244, 63, 94, 0.2)` accompanied by bold crimson text.